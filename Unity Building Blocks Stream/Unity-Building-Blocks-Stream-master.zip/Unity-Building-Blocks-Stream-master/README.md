# Unity-Building-Blocks-Stream
Repo for my upcoming live-stream on Unity's YouTube channel teaching beginners all about GameObjects &amp; Components
